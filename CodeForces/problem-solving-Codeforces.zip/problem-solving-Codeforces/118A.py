# n=input()
# n_lower=n.lower()
# vowels=["a","e","i","o","u"]
# for j in n:
#     for j not in vowels:
#         print(j)
    