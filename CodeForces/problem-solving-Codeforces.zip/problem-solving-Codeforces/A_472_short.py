n= int(input())
if n % 2 == 0 :
    print(8,n-8)
else:
    print(9,n-9)