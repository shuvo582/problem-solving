n=5 
arr=[5, 4, 3, 2, 1]
arr_1=[]

while n >= 1 :
    # arr.append(arr[n-1])
    print(n)
    n= n-1