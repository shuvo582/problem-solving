n=int(input())
shuvo={}
def soln(n):
    for i in range(n):
        a,b=map(int,input().split())
        shuvo{a:b}
        print(shuvo)