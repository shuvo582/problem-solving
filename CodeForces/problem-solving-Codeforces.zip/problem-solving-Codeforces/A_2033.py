def A2033():
    t=int(input())
    for i in range(t):
        n=int(input())
        if n % 2 == 0:
            print("Sakurako")
        else:
            print("Kosuke") 
A2033()    